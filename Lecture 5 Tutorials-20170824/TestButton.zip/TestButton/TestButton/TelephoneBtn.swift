//
//  CircleButton.swift
//  TestButton
//
//  Created by Christine Jiang on 18/08/17.
//  Copyright © 2017 Christine Jiang. All rights reserved.
//

import UIKit

class TelephoneBtn : UIButton
{
    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
        
        self.layer.borderWidth = 1
        self.backgroundColor = UIColor.white
        self.layer.borderColor = UIColor(red:0, green:0 , blue:255/255, alpha:0.3).cgColor
        self.layer.cornerRadius = 5
        
        if let image = UIImage(named: "callBtn")
        {
            self.setImage(image, for: .normal)
        }
        if let image = UIImage(named: "callBtnFilled")
        {
            self.setImage(image, for: .highlighted)
        }
    }
}
