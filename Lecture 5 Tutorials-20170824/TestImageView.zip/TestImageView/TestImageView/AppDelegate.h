//
//  AppDelegate.h
//  TestImageView
//
//  Created by Ying Jiang on 27/02/16.
//  Copyright © 2016 Unitec. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

