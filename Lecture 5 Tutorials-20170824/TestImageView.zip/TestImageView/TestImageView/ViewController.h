//
//  ViewController.h
//  TestImageView
//
//  Created by Ying Jiang on 27/02/16.
//  Copyright © 2016 Unitec. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *imageView;

- (IBAction)changeBtnDidTap:(id)sender;

@end

