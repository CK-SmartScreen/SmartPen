//
//  ViewController.m
//  TestImageView
//
//  Created by Ying Jiang on 27/02/16.
//  Copyright © 2016 Unitec. All rights reserved.
//

#import "ViewController.h"

#define AppleBlackAndWhite @"appleLogo"
#define AppleRainbow @"appleRainbow"

@interface ViewController ()
{
  BOOL _isRainbow;
}


@end

@implementation ViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
  // Dispose of any resources that can be recreated.
}

- (IBAction)changeBtnDidTap:(id)sender
{
  _isRainbow = !_isRainbow;
//  if (_isRainbow)
//  {
//    self.imageView.image = [UIImage imageNamed:AppleBlackAndWhite];
//  }
//  else
//  {
//    self.imageView.image = [UIImage imageNamed:AppleRainbow];
//  }
  
//  self.imageView.image = _isRainbow ? [UIImage imageNamed:AppleRainbow] : [UIImage imageNamed:AppleBlackAndWhite];

  [UIView transitionWithView:self.imageView
                    duration:1.f
                     options:UIViewAnimationOptionTransitionFlipFromLeft
                  animations:^{
    self.imageView.image = _isRainbow ? [UIImage imageNamed:AppleRainbow] : [UIImage imageNamed:AppleBlackAndWhite];
  } completion:nil];
}

@end
