//
//  ViewController.swift
//  TestImageViewSwift
//
//  Created by Christine Jiang on 23/08/17.
//  Copyright © 2017 Christine Jiang. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var imageView: UIImageView!
    var isRainbow = false
    let bwLogoName = "appleLogo"
    let colorLogoName = "appleRainbow"
    
    @IBAction func inforBtnDidTap(_ sender: Any)
    {
        self.isRainbow = !self.isRainbow
        
        UIView.transition(with: self.imageView,
                          duration: 1,
                          options: .transitionFlipFromLeft,
                          animations: {
            self.imageView.image = self.isRainbow
                ? UIImage(named: self.colorLogoName)
                : UIImage(named: self.bwLogoName)
        }, completion: nil)
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

